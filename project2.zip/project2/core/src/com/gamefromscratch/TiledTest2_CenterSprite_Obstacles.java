/**
 *  From the "adding a sprite and dealing with layers" demo at
 *  http://www.gamefromscratch.com/post/2014/05/01/LibGDX-Tutorial-11-Tiled-Maps-Part-2-Adding-a-character-sprite.aspx
 *
 *  Fall 2020: This is TiledTest2 modified to move the Sprite with the arrow keys while
 *             automatically scrolling the background tile map to keep the Sprite centered.
 *             Additional code was added to allow 8 direction movement with arrow key
 *             combinations and to allow the arrow keys to be held down.
 *
 *             Enabled obstacles (shrubbery) from layer 2 of tile map, using the array of
 *             Rectangles approach of the Legend of Capybara's FarmScreen level:
 *
 *             https://cssegit.monmouth.edu/s0975195/TheLegendOfCapybara/-/blob/master/core/src/com/capybara/game/FarmScreen.java
 */

package com.gamefromscratch;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapRenderer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.Rectangle; // Fall 2020: for obstacles
import com.badlogic.gdx.utils.Array;    // Fall 2020: for obstacles

public class TiledTest2_CenterSprite_Obstacles implements Screen, InputProcessor {
    final TiledGame game;

    // Our bread crumb back to the main menu:
    MainMenuScreen mainmenu;

    Texture img;
    TiledMap tiledMap;
    OrthographicCamera camera;
    TiledMapRenderer tiledMapRenderer;
    Texture texture;
    Sprite sprite;

    // Fall 2020:
    float tiledMapWidth; // pixels
    float tiledMapHeight;

    // Fall 2020: Allow 8 direction movement and holding down direction keys.
    boolean isLEFT;
    boolean isRIGHT;
    boolean isUP;
    boolean isDOWN;
    float moveIncr = 4; // Move sprite and camera this much with arrow keys (32 is too large).

    // Fall 2020: Enable obstacles using Rectangles.
    Array<Rectangle> obstacles;
    Rectangle shrub1;
    Rectangle bush1;
    // Get coordinates and sizes of obstacle Rectangles from
    // DEBUG statement in touchDown() method below.

    // For mouse click placement of sprite in touchDown() method.
    Vector3 clickCoordinates;
    Vector3 position;

    public TiledTest2_CenterSprite_Obstacles(final TiledGame gam, MainMenuScreen pmainmenu) {
        this.game = gam;
        this.mainmenu = pmainmenu;

        // Detect width and height of current game window.
        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();

        camera = new OrthographicCamera();
        camera.setToOrtho(false, w, h);
        tiledMap = new TmxMapLoader().load("tileset_map_1.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);
        Gdx.input.setInputProcessor(this);

        // Fall 2020: Use version of creature.png with tighter cropping of borders.
        // texture = new Texture(Gdx.files.internal("creature.png"));
        texture = new Texture(Gdx.files.internal("creature_cropped.png"));
        sprite = new Sprite(texture);

        // (Fall 2020) Get tiled map properties (https://is.gd/vNoA6P)
        MapProperties properties = tiledMap.getProperties();
        int tileWidth         = properties.get("tilewidth", Integer.class); // See tileset_map_1.tmx
        int tileHeight        = properties.get("tileheight", Integer.class);
        int mapWidthInTiles   = properties.get("width", Integer.class);
        int mapHeightInTiles  = properties.get("height", Integer.class);
        tiledMapWidth  = mapWidthInTiles * tileWidth;
        tiledMapHeight = mapHeightInTiles * tileHeight;
        // (Fall 2020) Make camera point to middle of tiled map.
        camera.position.x = tiledMapWidth / 2;
        camera.position.y = tiledMapHeight / 2;
        // (Fall 2020) Center sprite on screen at start:
        // (Fall 2022) Shift sprite right 20 pixels:
        sprite.setPosition(tiledMapWidth/2 - sprite.getWidth()/2 + 20, tiledMapHeight/2 - sprite.getHeight()/2);

        // (Fall 2020) Sets the positions and sizes of the obstacle Rectangles
        shrub1 = new Rectangle(400, 670, 25, 70);
        bush1 = new Rectangle(600, 570, 45, 80);
        // Adds all the obstacles to an Array
        obstacles = new Array<Rectangle>();
        obstacles.add(shrub1);
        obstacles.add(bush1);
    } // end constructor

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        tiledMapRenderer.setView(camera);
        tiledMapRenderer.render();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();
        sprite.draw(game.batch);
        // game.font.draw(game.batch, "(Hit Escape to return to main menu)", 10, 450);
        // (Fall 2022) The drawn text has to follow the camera around now.
        game.font.draw(game.batch, "(Hit Escape to return to main menu)", camera.position.x-380, camera.position.y+220);
        game.batch.end();

        // (Fall 2020) Move sprite and camera.
        updateScreen();
    }

    // Move sprite and camera with arrow keys.
    private void updateScreen() {
        // (Fall 2020) Eight direction movement;
        //             Keep sprite centered, while moving map.
        //             Keep sprite from moving off map.
        float spriteNewX = sprite.getX();
        float spriteNewY = sprite.getY();
        float cameraMoveX = 0;
        float cameraMoveY = 0;

        if (isLEFT && isUP) {
            spriteNewX = sprite.getX() - moveIncr;
            spriteNewY = sprite.getY() + moveIncr;
            cameraMoveX = -moveIncr; cameraMoveY = moveIncr;
        } else if (isRIGHT && isUP) {
            spriteNewX = sprite.getX() + moveIncr;
            spriteNewY = sprite.getY() + moveIncr;
            cameraMoveX = moveIncr; cameraMoveY = moveIncr;
        } else if (isLEFT && isDOWN) {
            spriteNewX = sprite.getX() - moveIncr;
            spriteNewY = sprite.getY() - moveIncr;
            cameraMoveX = -moveIncr; cameraMoveY = -moveIncr;
        } else if (isRIGHT && isDOWN) {
            spriteNewX = sprite.getX() + moveIncr;
            spriteNewY = sprite.getY() - moveIncr;
            cameraMoveX = moveIncr; cameraMoveY = -moveIncr;
        } else if (isLEFT) {
            spriteNewX = sprite.getX() - moveIncr;
            cameraMoveX = -moveIncr; cameraMoveY = 0;
        } else if (isRIGHT) {
            spriteNewX = sprite.getX() + moveIncr;
            cameraMoveX = moveIncr; cameraMoveY = 0;
        } else if (isUP) {
            spriteNewY = sprite.getY() + moveIncr;
            cameraMoveX = 0; cameraMoveY = moveIncr;
        } else if (isDOWN) {
            spriteNewY = sprite.getY() - moveIncr;
            cameraMoveX = 0; cameraMoveY = -moveIncr;
        } else {
            // noop
        }

        // No change in x if about to move off map.
        if (spriteNewX - moveIncr < 0 || spriteNewX + sprite.getWidth() + moveIncr > tiledMapWidth) {
            spriteNewX = sprite.getX();
            cameraMoveX = 0;
        }
        // No change in y if about to move off map.
        if (spriteNewY + sprite.getHeight() + moveIncr > tiledMapHeight || spriteNewY - moveIncr < 0) {
            spriteNewY = sprite.getY();
            cameraMoveY = 0;
        }

        // No change in x if about to overlap an obstacle.
        Rectangle spriteBoxShiftLeft = new Rectangle(spriteNewX - moveIncr, spriteNewY, sprite.getWidth(), sprite.getHeight());
        Rectangle spriteBoxShiftRight = new Rectangle(spriteNewX + moveIncr, spriteNewY, sprite.getWidth(), sprite.getHeight());
        for (Rectangle obstacle : obstacles) {
            if (spriteBoxShiftLeft.overlaps(obstacle) || spriteBoxShiftRight.overlaps(obstacle)) {
                spriteNewX = sprite.getX();
                cameraMoveX = 0;
            }
        }
        // No change in y if about to overlap an obstacle.
        Rectangle spriteBoxShiftUp = new Rectangle(spriteNewX, spriteNewY + moveIncr, sprite.getWidth(), sprite.getHeight());
        Rectangle spriteBoxShiftDown = new Rectangle(spriteNewX, spriteNewY - moveIncr, sprite.getWidth(), sprite.getHeight());
        for (Rectangle obstacle : obstacles) {
            if (spriteBoxShiftUp.overlaps(obstacle) || spriteBoxShiftDown.overlaps(obstacle)) {
                spriteNewY = sprite.getY();
                cameraMoveY = 0;
            }
        }

        sprite.setPosition(spriteNewX, spriteNewY);
        camera.translate(cameraMoveX, cameraMoveY);

        // (Fall 2020) Debugging:
        // System.out.println("camera: " + camera.position.x + ", " + camera.position.y);
        // System.out.println("sprite: " + sprite.getX() + ", " + sprite.getY());
    } // end updateScreen()

    // InputProcessor interface method overrides:
    @Override public boolean keyDown(int keycode) {
        // (Fall 2020) Set direction arrow booleans to allow key holding.
        if(keycode == Input.Keys.LEFT)  isLEFT  = true;
        if(keycode == Input.Keys.RIGHT) isRIGHT = true;
        if(keycode == Input.Keys.UP)    isUP    = true;
        if(keycode == Input.Keys.DOWN)  isDOWN  = true;

        return false;
    }

    @Override public boolean keyUp(int keycode) {
        // (Fall 2020) Key has been released, so set appropriate booleans to false.
        if(keycode == Input.Keys.LEFT)  isLEFT  = false;
        if(keycode == Input.Keys.RIGHT) isRIGHT = false;
        if(keycode == Input.Keys.UP)    isUP    = false;
        if(keycode == Input.Keys.DOWN)  isDOWN  = false;

        if(keycode == Input.Keys.ESCAPE) {
            game.setScreen(mainmenu);
            dispose();
        }

        return false;
    }

    @Override public boolean keyTyped(char character) {
        return false;
    }

    // Can use this touchDown method to get obstacle coordinates and dimensions.
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        clickCoordinates = new Vector3(screenX,screenY,0);
        position = camera.unproject(clickCoordinates);
        // Fall 2020: DEBUG
        System.out.println("Pointer x: " + position.x + ", y:" + position.y);
        return true;
    }

    @Override public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }

    // Screen interface method overrides:
    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

}
