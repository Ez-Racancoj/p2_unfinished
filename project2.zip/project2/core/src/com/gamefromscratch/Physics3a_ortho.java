package com.gamefromscratch;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.Animation;


public class Physics3a_ortho implements Screen, InputProcessor {
    final TiledGame game;

    // Our bread crumb back to the main menu:
    MainMenuScreen mainmenu;

    Sprite sprite;
    Texture img;
    World world;
    Body body; // The sprite dynamic body
    Body bodyEdgeScreen; // The floor static body

    Box2DDebugRenderer debugRenderer;
    Matrix4 debugMatrix;
    OrthographicCamera camera;
    private static final float ANIMATION_FRAME_DURATION = 1/15f;// Project 2
    private static final int FRAME_COLS = 4;// Project 2
    private static final int FRAME_ROWS = 4;// Project 2

    private TextureAtlas spriteAtlas;// Project 2
    private Animation<TextureRegion> walkLeftAnimation;// Project 2
    private Animation<TextureRegion> walkRightAnimation;// Project 2
    private float time = 0;//Project 2
    boolean drawSprite = true;

    // boolean vars for sprite movement
    boolean right, left, jump;

    final float PIXELS_TO_METERS = 100f;

    public Physics3a_ortho(final TiledGame gam, MainMenuScreen pmainmenu) {
        this.game = gam;
        this.mainmenu = pmainmenu;

        // Put Gdx.graphics origin in lower left with setToOrtho,
        // else the origin will be in the middle.
        camera = new OrthographicCamera();
        camera.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        spriteAtlas = new TextureAtlas(Gdx.files.internal("proj2_sprite/p2_anim_sprite.atlas"));//Project 2
        sprite = new Sprite();//Project 2
        walkLeftAnimation = new Animation<TextureRegion>(ANIMATION_FRAME_DURATION, spriteAtlas.findRegions("walk_left"));//Project 2
        walkRightAnimation = new Animation<TextureRegion>(ANIMATION_FRAME_DURATION, spriteAtlas.findRegions("walk_right"));//Project 2


        //img = new Texture("badlogic.jpg");
        //sprite = new Sprite(img);

        //sprite's initial position (mid-upper part of screen)
        sprite.setPosition(Gdx.graphics.getWidth() / 2 - sprite.getWidth() / 2,
               Gdx.graphics.getHeight() / 2);

        // This world has a force acting downward in the y direction, i.e., some kind of gravity.
        world = new World(new Vector2(0, -10f), true);

        // Define box2d body for the sprite
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        // The body's position in meters is set using the middle of the body,
        // while the sprite's position is set using the lower left corner of the sprite.
        bodyDef.position.set((sprite.getX() + sprite.getWidth() / 2) / PIXELS_TO_METERS,
                (sprite.getY() + sprite.getHeight() / 2) / PIXELS_TO_METERS);

        body = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        // The setAsBox() method takes half-width and half-height as arguments
        shape.setAsBox(sprite.getWidth() / 2 / PIXELS_TO_METERS,
                sprite.getHeight() / 2 / PIXELS_TO_METERS);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 0.01f;

        body.createFixture(fixtureDef);
        shape.dispose();

        // Define box2d body for the floor
        BodyDef bodyDef2 = new BodyDef();
        bodyDef2.type = BodyDef.BodyType.StaticBody;
        float w = Gdx.graphics.getWidth() / PIXELS_TO_METERS;  // width in meters
        float h = Gdx.graphics.getHeight() / PIXELS_TO_METERS; // height in meters
        bodyDef2.position.set(0, 0);
        FixtureDef fixtureDef2 = new FixtureDef();

        EdgeShape edgeShape = new EdgeShape();
        edgeShape.set(0, 0.2f, w, 0.2f); // bottom edge (.2m height)
        fixtureDef2.shape = edgeShape;

        bodyEdgeScreen = world.createBody(bodyDef2);
        bodyEdgeScreen.createFixture(fixtureDef2);
        edgeShape.dispose();

        Gdx.input.setInputProcessor(this);

        debugRenderer = new Box2DDebugRenderer();
    } // constructor

    public void render(float delta) {
        camera.update();
        // Step the physics simulation forward at a rate of 60hz.
        world.step(1f / 60f, 6, 2);

        sprite.setPosition((body.getPosition().x * PIXELS_TO_METERS) - sprite.getWidth() / 2,
                (body.getPosition().y * PIXELS_TO_METERS) - sprite.getHeight() / 2);

        sprite.setRotation((float) Math.toDegrees(body.getAngle()));

        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.batch.setProjectionMatrix(camera.combined);
        debugMatrix = game.batch.getProjectionMatrix().cpy().scale(PIXELS_TO_METERS, PIXELS_TO_METERS, 0);

        game.batch.begin();
        if (drawSprite)
            sprite.draw(game.batch);
        game.font.draw(game.batch, "(Hit Escape to return to main menu)", 10, Gdx.graphics.getHeight() - 10);
        game.batch.end();

        // Move sprite
        updateSprite();

        debugRenderer.render(world, debugMatrix);
    } // end render()


    private void updateSprite() {
        // Get current y velocity
        float vy = body.getLinearVelocity().y;
        // Debug:
        // System.out.println("vy: " + vy);

        // If not currently jumping ...
        float notJumpingThreshold = .01f;
        if (Math.abs(vy) < notJumpingThreshold ) {
            if (right)
            {
                body.setLinearVelocity(1f, 0);
                drawSprite = true;//Project 2
                sprite.setRegion(walkRightAnimation.getKeyFrame(time, true));//Project 2
            }
        else if (left) //Project 2 changed if to else if
            {
                body.setLinearVelocity(-1f, 0);
                drawSprite = true;//Project 2
                sprite.setRegion(walkLeftAnimation.getKeyFrame(time, true));//Projcet 2
            }
        else //Project 2
        {
            drawSprite = false;
        }

            if (jump)
                body.applyForceToCenter(0f, 5f, true);
        }
    }

    // InputProcessor interface method overrides:
    @Override
    public boolean keyDown(int keycode) {
        if (keycode == Input.Keys.RIGHT)
            right = true;
        if (keycode == Input.Keys.LEFT)
            left = true;
        // Jump with UP
        if (keycode == Input.Keys.UP)
            jump = true;

        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        if (keycode == Input.Keys.RIGHT)
            right = false;
            // body.setLinearVelocity(1f, 0f);
        if (keycode == Input.Keys.LEFT)
            left = false;
            // body.setLinearVelocity(-1f, 0f);

        // Jump with UP
        if (keycode == Input.Keys.UP)
            jump = false;
            // body.applyForceToCenter(0f, 5f, true);

        // Reset everything with SPACE
        if (keycode == Input.Keys.SPACE) {
            body.setLinearVelocity(0f, 0f);
            body.setAngularVelocity(0f);

            sprite.setPosition(Gdx.graphics.getWidth() / 2 - sprite.getWidth() / 2,
                    Gdx.graphics.getHeight() / 2);
            body.setTransform((sprite.getX() + sprite.getWidth() / 2) / PIXELS_TO_METERS,
                    (sprite.getY() + sprite.getHeight() / 2) / PIXELS_TO_METERS, 0f);
        }

        // Toggle sprite visibility with 1
        if (keycode == Input.Keys.NUM_1)
            drawSprite = !drawSprite;

        // Escape to MainMenuScreen
        if (keycode == Input.Keys.ESCAPE) {
            game.setScreen(mainmenu);
            dispose();
        }

        return false;
    } // end keyUp()

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }


    // Screen interface method overrides:
    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(this);//Project 2
    }


    @Override
    public void hide() {
    }

    @Override
    public void dispose() {
        spriteAtlas.dispose();//Project 2
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

}
