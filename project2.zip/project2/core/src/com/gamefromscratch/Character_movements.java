/*
package com.gamefromscratch;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;

public class Character_movements {
    Box2DDebugRenderer debugRenderer;
    private Physics3a_ortho physics3;

    @Override
    public boolean keyUp(int keycode) {
        if (keycode == Input.Keys.RIGHT)
            right = false;
        // body.setLinearVelocity(1f, 0f);
        if (keycode == Input.Keys.LEFT)
            left = false;
        // body.setLinearVelocity(-1f, 0f);

        // Jump with UP
        if (keycode == Input.Keys.UP)
            jump = false;
        // body.applyForceToCenter(0f, 5f, true);

        // Reset everything with SPACE
        if (keycode == Input.Keys.SPACE) {
            body.setLinearVelocity(0f, 0f);
            body.setAngularVelocity(0f);

            sprite.setPosition(Gdx.graphics.getWidth() / 2 - sprite.getWidth() / 2,
                    Gdx.graphics.getHeight() / 2);
            body.setTransform((sprite.getX() + sprite.getWidth() / 2) / PIXELS_TO_METERS,
                    (sprite.getY() + sprite.getHeight() / 2) / PIXELS_TO_METERS, 0f);
        }

        // Toggle sprite visibility with 1
        if (keycode == Input.Keys.NUM_1)
            drawSprite = !drawSprite;

        // Escape to MainMenuScreen
        if (keycode == Input.Keys.ESCAPE) {
            game.setScreen(mainmenu);
            dispose();
        }

        return false;
    } // end keyUp()
}
*/
